import Phaser from "phaser"

const EVENTS = new Phaser.Events.EventEmitter()
export default EVENTS
